#    _*_ coding:utf-8 _*_
# ============================
# |     File:Straight_verify.py         |
# |     Author:Wolfgang      |
# |     Date:2020/8/25       |
# ============================
import numpy as np
thick = 0.002
width = 0.004
length = 0.1
if __name__ == '__main__':
    a = thick
    b = width
    l = length
    u0 = 4 * 1e-7 * np.pi


    def L_Grover():
        L = u0*l / 2 / np.pi * (np.log(2 * l / (a + b)) - 0.2235 * np.log((a + b) / l) + 0.5)
        return L


    def L_Kalantarov():
        L = u0 * l / 2 / np.pi * (np.log(2 * l / (a + b)) + 0.5)
        return L


    def L_Hoer():
        T1 = 3 * a ** 2 * l * np.log((l + np.sqrt(l ** 2 + a ** 2) / a))
        T2 = pow(l ** 2 + a ** 2, 3 / 2)
        T3 = 3 * a * l ** 2 * np.log((a + np.sqrt(a ** 2 + l ** 2) / l))
        L = u0 / 6 / np.pi / a ** 2 * (T1 - T2 + T3 + l ** 3 + a ** 3)
        return L
    def L_Zygmunt():
        T1=b/a*np.arctan(a/b)+a/b*np.arctan(b/a)
        T2 = (a/b)**2-6+(b/a)**2
        T3 = np.log(1+(a/b)**2)
        T4 = (6-(a/b)**2)*np.log(a/b)
        L = u0*l/2/np.pi*(np.log(2*l/a)+13/12-2/3*T1+T2*T3/12+T4/6)
        return L

    L1 = L_Grover()*1e9
    L2 = L_Kalantarov()*1e9
    L3 = L_Hoer()*1e9
    L4 = L_Zygmunt()*1e9
    print(L1,'nH', '\n', L2,'nH', '\n', L3,'nH','\n',L4,'nH')

