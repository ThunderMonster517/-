#    _*_ coding:utf-8 _*_
# ============================
# |     File:curve_verify.py |
# |     Author:Wolfgang      |
# |     Date:2020/9/2        |
# ============================

import numpy as np

myu0 = np.pi*4*1e-7
R0 = 0.05
Width = 0.004
Thickness = 0.002


def yut(x):
    y1 = np.pi * x / 3 - np.log(1 + x * x) / (12 * x * x) - x * x * np.log(1 + 1 / (x * x)) / 12 - 2 * (x - 1 / x) * (
        np.arctan(x)) / 3 - 1 / 12
    return y1


def yur(x):
    y2 = (69 / 20 + 221 / (60 * x * x) - np.log(1 + x * x) / (10 * x * x * x * x) + x * x * np.log(
        1 + 1 / (x * x)) / 2 - 8 * np.pi * x / 5 + 16 * x * np.arctan(x) / 5) / 6
    return y2


def L(a, b, c, y1, y2):
    y = myu0 * a * (
            (1 + (3 * b * b + c * c) / (96 * a * a)) * np.log(8 * a / np.sqrt(b * b + c * c)) - y1 + b * b * y2 / (
            16 * a * a))
    return y


coil_avg_r = R0 + Thickness / 2
coil_height = Width
coil_ply = Thickness
X = coil_height / coil_ply
arg_1 = yut(X)
arg_2 = yur(X)
sum0 = L(coil_avg_r, coil_height, coil_ply, arg_1, arg_2)

print(sum0*1e9, 'nH')

