#    _*_ coding:utf-8 _*_
# ============================
# |   File:numpy_integral.py |
# |     Author:Wolfgang      |
# |     Date:2020/8/21       |
# ============================

import numpy as np
from scipy import integrate
import time

myu0 = np.pi*4e-7
R0 = 0.05
STRAIGHT = 0.1
TURNS = 1
Div_C = 4
Div_S = 4
Div_All = 2*(Div_C+Div_S)
Width = 0.004
Thickness = 0.002
sub_straight = STRAIGHT / Div_S


def M(ti, zi, tj, zj, ii, jj, Ri, Rj):
    if 0 <= ii < Div_C:
        ri = Ri
    elif Div_C <= ii < (Div_C + Div_S):
        ri = Ri / np.cos(ti - np.pi)
    elif (Div_C + Div_S) <= ii < (Div_All - Div_S):
        yu = 2 * STRAIGHT * np.sqrt(
            (pow(Ri, 2) - pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - ti), 2) * pow(np.cos(1.5 * np.pi - ti), 2)))
        ri = np.sqrt(pow(STRAIGHT, 2) + pow(Ri, 2) - 2 * pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - ti), 2) + yu)
    else:
        ri = Ri / np.cos(2 * np.pi - ti)

    if 0 <= jj < Div_C:
        rj = Rj
    elif Div_C <= jj < (Div_C + Div_S):
        rj = Rj / np.cos(tj - np.pi)
    elif (Div_C + Div_S) <= jj < (Div_All - Div_S):
        yu = 2 * STRAIGHT * np.sqrt(
            (pow(Rj, 2) - pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - tj), 2) * pow(np.cos(1.5 * np.pi - tj), 2)))
        rj = np.sqrt(pow(STRAIGHT, 2) + pow(Rj, 2) - 2 * pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - tj), 2) + yu)
    else:
        rj = Rj / np.cos(2 * np.pi - tj)

    mutual = ri * rj * np.cos(tj - ti) / np.sqrt(
        pow(ri, 2) + pow(rj, 2) - 2 * ri * rj * np.cos(tj - ti) + pow(zj - zi, 2))
    return mutual


if __name__ == '__main__':
    Inductance_Matrix = np.zeros((Div_All * TURNS, Div_All * TURNS))
    start = time.perf_counter()
    for i in range(Div_All * TURNS):

        ii = i % Div_All
        Ti = i / Div_All
        Ri = R0 + Thickness * (Ti + 0.5)
        if ii < Div_C:
            ti_lower = np.pi / Div_C * ii
            ti_upper = np.pi / Div_C * (ii + 1)

        elif (Div_C + Div_S) > ii >= Div_C:
            surplus = ii - Div_C

            ti_lower = np.pi + np.arctan2(sub_straight * surplus, Ri)

            ti_upper = np.pi + np.arctan2(sub_straight * (surplus + 1), Ri)

        elif (2 * Div_C + Div_S) > ii >= (Div_All / 2):

            surplus = Div_All - Div_S - ii

            t_upper_x = Ri * np.cos((surplus - 1) * np.pi / Div_C)

            t_upper_y = -Ri * np.sin((surplus - 1) * np.pi / Div_C) - STRAIGHT

            t_lower_x = Ri * np.cos(surplus * np.pi / Div_C)

            t_lower_y = -Ri * np.sin(surplus * np.pi / Div_C) - STRAIGHT

            ti_lower = 2 * np.pi + np.arctan2(t_lower_y, t_lower_x)

            ti_upper = 2 * np.pi + np.arctan2(t_upper_y, t_upper_x)

        else:

            ti_lower = 2 * np.pi - np.arctan((Div_All - ii) * sub_straight / Ri)

            ti_upper = 2 * np.pi - np.arctan((Div_All - ii - 1) * sub_straight / Ri)

        zi_lower = 0
        zi_upper = Width
        for j in range(Div_All * TURNS):
            if j != i:
                jj = j % Div_All
                Tj = j / Div_All
                Rj = R0 + Thickness * (Tj + 0.5)
                if jj < Div_C:
                    tj_lower = np.pi / Div_C * jj
                    tj_upper = np.pi / Div_C * (jj + 1)

                elif (Div_C + Div_S) > jj >= Div_C:
                    surplus = jj - Div_C

                    tj_lower = np.pi + np.arctan2(sub_straight * surplus, Rj)

                    tj_upper = np.pi + np.arctan2(sub_straight * (surplus + 1), Rj)

                elif (2 * Div_C + Div_S) > jj >= (Div_All / 2):

                    surplus = Div_All - Div_S - jj

                    t_upper_x = Rj * np.cos((surplus - 1) * np.pi / Div_C)

                    t_upper_y = -Rj * np.sin((surplus - 1) * np.pi / Div_C) - STRAIGHT

                    t_lower_x = Rj * np.cos(surplus * np.pi / Div_C)

                    t_lower_y = -Rj * np.sin(surplus * np.pi / Div_C) - STRAIGHT

                    tj_lower = 2 * np.pi + np.arctan2(t_lower_y, t_lower_x)

                    tj_upper = 2 * np.pi + np.arctan2(t_upper_y, t_upper_x)

                else:

                    tj_lower = 2 * np.pi - np.arctan((Div_All - jj) * sub_straight / Rj)

                    tj_upper = 2 * np.pi - np.arctan((Div_All - jj - 1) * sub_straight / Rj)
                zj_lower = 0
                zj_upper = Width
                print(i, ii, '\t', j, jj, '\n', ti_lower, ti_upper, tj_lower, tj_upper)
                result = integrate.nquad(M, [(ti_lower, ti_upper), (zi_lower, zi_upper), (tj_lower, tj_upper),
                                             (zj_lower, zj_upper)], args=(ii, jj, Ri, Rj))
                result1 = 1e-7 / 0.004 ** 2 * result[0]

            else:
                result1 = 0
            Inductance_Matrix[i][j] = result1
            print(result1)

    output = open('Inductance_Matrix.xls', 'w', encoding='gbk')
    for i in range(len(Inductance_Matrix)):
        for j in range(len(Inductance_Matrix[i])):
            output.write(str(Inductance_Matrix[i][j]))  # 使用str()转化
            output.write('\t')  # 相当于Tab一下，换一个单元格
        output.write('\n')  # 写完一行立马换行
    output.close()
    end = time.perf_counter()
    print('Running time: %s Seconds' % (end - start))
