#    _*_ coding:utf-8 _*_
# ============================
# |     File:temp.py            |
# |     Author:Wolfgang      |
# |     Date:2020/9/2       |
# ============================
import numpy as np
from scipy import integrate

myu0 = np.pi * 4e-7
R0 = 0.03
STRAIGHT = 0.5
TURNS = 1
Div_C = 2
Div_S = 2
PERTURN = 8
Width = 0.004
Thickness = 0.00023
sub_straight = STRAIGHT / Div_S


def M(ti, zi, tj, zj, ii, jj, Ri, Rj):
    if 0 <= ii < Div_C:
        ri = Ri
    elif Div_C <= ii < (Div_C + Div_S):
        ri = Ri / np.cos(ti - np.pi)
    elif (Div_C + Div_S) <= ii < (PERTURN - Div_S):
        yu = 2 * STRAIGHT * np.sqrt(
            (pow(Ri, 2) - pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - ti), 2) * pow(np.cos(1.5 * np.pi - ti), 2)))
        ri = np.sqrt(pow(STRAIGHT, 2) + pow(Ri, 2) - 2 * pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - ti), 2) + yu)
    else:
        ri = Ri / np.cos(2 * np.pi - ti)

    if 0 <= jj < Div_C:
        rj = Rj
    elif Div_C <= jj < (Div_C + Div_S):
        rj = Rj / np.cos(tj - np.pi)
    elif (Div_C + Div_S) <= jj < (PERTURN - Div_S):
        yu = 2 * STRAIGHT * np.sqrt(
            (pow(Rj, 2) - pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - tj), 2) * pow(np.cos(1.5 * np.pi - tj), 2)))
        rj = np.sqrt(pow(STRAIGHT, 2) + pow(Rj, 2) - 2 * pow(STRAIGHT, 2) * pow(np.sin(1.5 * np.pi - tj), 2) + yu)
    else:
        rj = Rj / np.cos(2 * np.pi - tj)

    mutual = ri * rj * np.cos(tj - ti) / np.sqrt(
        pow(ri, 2) + pow(rj, 2) - 2 * ri * rj * np.cos(tj - ti) + pow(zj - zi, 2))
    return mutual


def yut(x):
    y1 = np.pi * x / 3 - np.log(1 + x * x) / (12 * x * x) - x * x * np.log(1 + 1 / (x * x)) / 12 - 2 * (x - 1 / x) * (
        np.arctan(x)) / 3 - 1 / 12
    return y1


def yur(x):
    y2 = (69 / 20 + 221 / (60 * x * x) - np.log(1 + x * x) / (10 * x * x * x * x) + x * x * np.log(
        1 + 1 / (x * x)) / 2 - 8 * np.pi * x / 5 + 16 * x * np.arctan(x) / 5) / 6
    return y2


def L(a, b, c, y1, y2):
    y = myu0 * a * (
            (1 + (3 * b * b + c * c) / (96 * a * a)) * np.log(8 * a / np.sqrt(b * b + c * c)) - y1 + b * b * y2 / (
            16 * a * a))
    return y


if __name__ == '__main__':
    # coil_avg_r = 0.0419
    # coil_height = 0.0041
    # coil_ply = 0.0038
    # X = coil_height / coil_ply
    # arg_1 = yut(X)
    # arg_2 = yur(X)
    # sum0 = L(coil_avg_r, coil_height, coil_ply, arg_1, arg_2)
    a = 0.05
    sum0 = (4 * np.pi * 20 ** 2 * a ** 2) / (0.2317 * a + 0.44 * 0.0041 + 0.39 * 0.0038)
    print(sum0, 'nH')
