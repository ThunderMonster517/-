import math
import numpy as np
straight = 100
Ri = 50
ti = 5


"""
zone 2

"""
# theta = math.asin(0.5 * straight * math.sin(math.pi / 2 - ti) / Ri)
# gama = math.pi/2 + ti - theta
# ri = 0.5 * straight / math.sin(ti) * math.sin(gama)
# a = gama + theta + math.pi / 2 - ti

"""
zone 3

"""
# theta = math.asin(0.5 * straight * math.sin(ti - math.pi / 2) / Ri)
# gama = 1.5 * math.pi - ti - theta
# ri = 0.5 * straight / math.sin(ti) * math.sin(gama)
# a = gama + theta + ti - math.pi / 2
"""
zone 6

"""
# theta = math.asin(0.5 * straight * math.sin(math.pi / 2*3-ti) / Ri)
# gama = ti-0.5*np.pi-theta
# ri = 0.5 * straight / math.sin(ti) * math.sin(gama)
# a = gama + theta +  math.pi / 2*3-ti

"""
zone 7

"""
alfa = ti - 1.5*np.pi
theta = math.asin(0.5 * straight * math.sin(alfa) / Ri)
gama = np.pi-alfa-theta
ri = Ri*np.sin(gama)/np.sin(alfa)
a = gama + theta + alfa

if (a == math.pi):
    print(ri)
    print('√')
else:
    print(ri)
    print('error')
