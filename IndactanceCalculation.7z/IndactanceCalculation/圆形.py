#    _*_ coding:utf-8 _*_
# ============================
# |   File:numpy_integral.py |
# |     Author:Wolfgang      |
# |     Date:2020/8/21       |
# ============================

import numpy as np
from scipy import integrate
import time

myu0 = np.pi * 4e-7
R0 = 0.05
TURNS = 1
Div_C = 4
Width = 0.004
Thickness = 0.002


def M(ti, zi, tj, zj, Ri, Rj):
    ri = Ri
    rj = Rj
    mutual = ri * rj * np.cos(tj - ti) / np.sqrt(
        pow(ri, 2) + pow(rj, 2) - 2 * ri * rj * np.cos(tj - ti) + pow(zj - zi, 2))
    return mutual


def L(a, b, c, y1, y2):
    y = myu0 * a * (
            (1 + (3 * b * b + c * c) / (96 * a * a)) * np.log(8 * a / np.sqrt(b * b + c * c)) - y1 + b * b * y2 / (
            16 * a * a))
    return y


if __name__ == '__main__':
    Inductance_Matrix = np.zeros((Div_C * TURNS, Div_C * TURNS))
    start = time.perf_counter()
    for i in range(Div_C * TURNS):
        Ri = R0 + Thickness * 0.5
        ti_lower = 2*np.pi / Div_C * i
        ti_upper = 2*np.pi / Div_C * (i + 1)
        zi_lower = 0
        zi_upper = Width
        for j in range(Div_C * TURNS):
            if j != i:
                Rj = R0 + Thickness * 0.5
                tj_lower = 2*np.pi / Div_C * j
                tj_upper = 2*np.pi / Div_C * (j + 1)
                zj_lower = 0
                zj_upper = Width
                print(i, '\t', j, '\n', ti_lower, ti_upper, tj_lower, tj_upper)
                result = integrate.nquad(M, [(ti_lower, ti_upper), (zi_lower, zi_upper), (tj_lower, tj_upper),
                                             (zj_lower, zj_upper)], args=(Ri, Rj))
                result1 = 1e-7 / 0.004 ** 2 * result[0]

            else:
                continue
            Inductance_Matrix[i][j] = result1
            print(result1)

    output = open('Inductance_Matrix.xls', 'w', encoding='gbk')
    for i in range(len(Inductance_Matrix)):
        for j in range(len(Inductance_Matrix[i])):
            output.write(str(Inductance_Matrix[i][j]))  # 使用str()转化
            output.write('\t')  # 相当于Tab一下，换一个单元格
        output.write('\n')  # 写完一行立马换行
    output.close()
    end = time.perf_counter()
    print('Running time: %s Seconds' % (end - start))
