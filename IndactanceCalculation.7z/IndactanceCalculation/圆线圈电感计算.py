import numpy as np
from scipy import integrate
import time

myu0 = np.pi*4e-7
R0 = 0.03
TURNS = 1
Div = 3
Width = 0.004
Thickness = 0.001

def Mutual(ti, zi, tj, zj, i, j):
    ri = R0+(0.5+i)*Thickness
    rj = R0 + (0.5 + j) * Thickness
    mutual = ri * rj * np.cos(tj - ti) / np.sqrt(
        pow(ri, 2) + pow(rj, 2) - 2 * ri * rj * np.cos(tj - ti) + pow(zj - zi, 2))
    return mutual


def yut(x):
    y1 = np.pi * x / 3 - np.log(1 + x * x) / (12 * x * x) - x * x * np.log(1 + 1 / (x * x)) / 12 - 2 * (x - 1 / x) * (
        np.arctan(x)) / 3 - 1 / 12
    return y1


def yur(x):
    y2 = (69 / 20 + 221 / (60 * x * x) - np.log(1 + x * x) / (10 * x * x * x * x) + x * x * np.log(
        1 + 1 / (x * x)) / 2 - 8 * np.pi * x / 5 + 16 * x * np.arctan(x) / 5) / 6
    return y2


def L(a, b, c, y1, y2):
    y = myu0 * a * (
            (1 + (3 * b * b + c * c) / (96 * a * a)) * np.log(8 * a / np.sqrt(b * b + c * c)) - y1 + b * b * y2 / (
            16 * a * a))
    return y


if __name__ == '__main__':
    Inductance_Matrix = np.zeros((Div * TURNS, Div * TURNS))
    for i in range(Div * TURNS):
        start = time.perf_counter()

        ti_lower = i*2*np.pi/Div
        ti_upper = (i+1)*2*np.pi/Div
        zi_lower = 0
        zi_upper = Width
        for j in range(Div * TURNS):
            if j != i:
                tj_lower = j*2*np.pi/Div
                tj_upper = (j+1)*2*np.pi/Div
                zj_lower = 0
                zj_upper = Width
                print(i, '\t', j, '\n', ti_lower, ti_upper, tj_lower, tj_upper)
                result = integrate.nquad(Mutual, [(ti_lower, ti_upper), (zi_lower, zi_upper), (tj_lower, tj_upper),
                                             (zj_lower, zj_upper)], args=(i, j))
                result1 = 1e-7 / 0.004 ** 2 * result[0]

            else:
                result1 = 0
            Inductance_Matrix[i][j] = result1
            print(result1)
            end = time.perf_counter()
            print('Running time: %s Seconds' % (end - start))

    # # self inductance calculation
    # for k in range(0, Div * TURNS, Div):
    #     coil_avg_r = R0 + k / Div * Thickness + Thickness / 2
    #     coil_height = Width
    #     coil_ply = Thickness
    #     X = coil_height / coil_ply
    #     arg_1 = yut(X)
    #     arg_2 = yur(X)
    #     # N = TURNS
    #     sum0 = L(coil_avg_r, coil_height, coil_ply, arg_1, arg_2) / 2
    #     sum1 = 0
    #     sum2 = 0
    #     for i in range(1, Div, 1):
    #         for j in range(0, i, 1):
    #             sum1 += Inductance_Matrix[k + i][k + j]
    #     for i in range(Div + Div_S, Div - Div_S, 1):
    #         for j in range(Div + Div_S, i, 1):
    #             sum2 += Inductance_Matrix[k + i][k + j]
    #
    #     rc1 = (sum0 - 2 * sum1) / Div
    #     rc2 = (sum0 - 2 * sum2) / Div
    #     for i in range(Div):
    #         Inductance_Matrix[k + i][k + i] = rc1
    #         Inductance_Matrix[k + Div_S + Div + i][k + Div_S + Div + i] = rc2
    #
    #     for s in range(Div * TURNS):
    #         ree = s % Div + 1
    #         rs = 0.5 * 1e-7 * sub_straight
    #         if (Div + Div_S) >= ree > Div:
    #             Inductance_Matrix[s][s] = rs
    #         elif Div >= ree > (2 * Div + Div_S):
    #             Inductance_Matrix[s][s] = rs
    #
    # output = open('data1.xls', 'w', encoding='gbk')
    # for i in range(len(Inductance_Matrix)):
    #     for j in range(len(Inductance_Matrix[i])):
    #         output.write(str(Inductance_Matrix[i][j]))  # 使用str()转化
    #         output.write('\t')  # 相当于Tab一下，换一个单元格
    #     output.write('\n')  # 写完一行立马换行
    # output.close()
