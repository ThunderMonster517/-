#    _*_ coding:utf-8 _*_
# ============================
# |   File:numpy_integral.py |
# |     Author:Wolfgang      |
# |     Date:2020/12/29      |
# ============================

import numpy as np
import time

myu0 = np.pi*4e-7
R0 = 0.05
STRAIGHT = 0.1
Div_C = 2
Div_S = 1
PERTURN = 2*(Div_C+Div_S)
Width = 0.004
Thickness = 0.002
sub_straight = STRAIGHT / Div_S


if __name__ == '__main__':
    Integral = np.zeros(PERTURN+1 )
    for i in range(PERTURN):
        start = time.perf_counter()
        Ri = R0 + Thickness * 0.5
        if i < Div_C:
            lower = np.pi / Div_C * i
            upper = np.pi / Div_C * (i + 1)

        elif (Div_C + Div_S) > i >= Div_C:
            surplus = i - Div_C

            lower = np.pi + np.arctan2(sub_straight * surplus, Ri)

            upper = np.pi + np.arctan2(sub_straight * (surplus + 1), Ri)

        elif (2 * Div_C + Div_S) > i >= (PERTURN / 2):

            surplus = PERTURN - Div_S - i

            t_upper_x = Ri * np.cos((surplus - 1) * np.pi / Div_C)

            t_upper_y = -Ri * np.sin((surplus - 1) * np.pi / Div_C) - STRAIGHT

            t_lower_x = Ri * np.cos(surplus * np.pi / Div_C)

            t_lower_y = -Ri * np.sin(surplus * np.pi / Div_C) - STRAIGHT

            lower = 2 * np.pi + np.arctan2(t_lower_y, t_lower_x)

            upper = 2 * np.pi + np.arctan2(t_upper_y, t_upper_x)

        else:

            lower = 2 * np.pi - np.arctan((PERTURN - i) * sub_straight / Ri)

            upper = 2 * np.pi - np.arctan((PERTURN - i - 1) * sub_straight / Ri)

        Integral[i] = lower
        Integral[i+1] = upper

    end = time.perf_counter()
    print('Running time: %s Seconds' % (end - start))
    print('积分区间为：', Integral)


